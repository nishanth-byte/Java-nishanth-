/*
Q5.Write a Java Program to print the given fractional number.
*/
import java.util.Scanner;
public class Q5 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        double num = sc.nextDouble();
        System.out.println("Given Fraction Number is : " + num);
        sc.close();
    }
}
