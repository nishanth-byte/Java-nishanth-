/*
Q25.Write a Java Program to print your address in multiple lines using \n.
*/
public class Q25 {
    public static void main(String[] args) {
        System.out.println("123, MG Road \n Bengaluru \n Karnataka \n India");
    }
}
