import java.util.Scanner;
public class Q12 {
  public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        char ch = sc.next().charAt(0);
        int a = ch;
        System.out.println("ASCII value is : "+a);
        sc.close();
    }   
}
