public class Q19 {
    public static void main(String[] args){
        int num = 12;
        System.out.println("+"+num);
    }
}
