public class Q22s {
    public static void main(String[] args) {
        int sub1 = 85;
        int sub2 = 90;
        int sub3 = 78;
        int sub4 = 92;
        int sub5 = 88;

        System.out.println("Marks in 5 subjects:");
        System.out.println("Subject 1: " + sub1);
        System.out.println("Subject 2: " + sub2);
        System.out.println("Subject 3: " + sub3);
        System.out.println("Subject 4: " + sub4);
        System.out.println("Subject 5: " + sub5);
    }
}
