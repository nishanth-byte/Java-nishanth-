import java.util.Scanner;
public class Q11 {
  public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        char ch = (char)a;
        System.out.println("ASCII Value of Charracter : "+ ch);
        sc.close();
    }   
}
