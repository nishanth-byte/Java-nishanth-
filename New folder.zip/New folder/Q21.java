public class Q21 {
    public static void main(String[] args){
        int RollNO = 123;
        String name = "Akash";
        System.out.println("RollNo : "+RollNO+"\n"+"Name : "+name);
    }
}
