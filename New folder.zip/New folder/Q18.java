public class Q18 {
    public static void main(String[] args){
        int date = 12;
        int month = 12;
        int year = 2012;
        System.out.printf("%02d/%02d/%04d", date, month, year);
    }
}
