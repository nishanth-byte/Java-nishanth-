public class Q20 {
    public static void main(String[] args){
        System.out.println("Size of byte : " + Byte.BYTES);
        System.out.println("Size of short : " + Short.BYTES);
        System.out.println("Size of long : " + Long.BYTES);
        System.out.println("Size of int : " + Integer.BYTES);
        System.out.println("Size of float : " + Float.BYTES);
        System.out.println("Size of double : " + Double.BYTES);
        System.out.println("Size of char : " + Character.BYTES);
    }
}
