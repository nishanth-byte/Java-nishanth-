public class Q6 {
    public static void main(String[] args) {
        double num = 12.34567;
        System.out.printf("%.2f", num);
    }
}
