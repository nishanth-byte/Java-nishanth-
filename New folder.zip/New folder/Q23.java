public class Q23 {
    public static void main(String[] args){
        String bloodGroup = "O +ve";
        System.out.println("Blood Group: " + bloodGroup);
    }
}
